# Prototipo Sanità Digitale Accessibile

Applicazione sanitaria digitale per anziani fragili conforme WCAG 2.1 AA.

## Caratteristiche Principali

### Schermate
- **Home** - Dashboard personalizzata
- **Ricette** - Gestione prescrizioni mediche
- **Visite** - Appuntamenti e prenotazioni
- **Profilo** - Dati personali e impostazioni
- **SOS** - Contatti emergenza

### Funzionalità
- Navigazione bottom tab consistente
- Input vocale integrato
- Pairing dispositivi IoT
- Navigazione completa da tastiera
- Personalizzazione per 3 personas

## Personas

### Maria (72 anni) - Presbiopia
- Font Size: 18px
- Complexity: Simple
- Language: Plain Language
- Color Mode: Light

### Giorgio (68 anni) - Tremore mani
- Pulsanti grandi (>72px)
- Complexity: Medium
- Spazi generosi tra elementi

### Angela (75 anni) - MCI
- Color Mode: High Contrast
- Language: Icons Only
- UI minimalista

## Stack Tecnologico

- React 18+ con TypeScript
- Tailwind CSS v4
- Motion (animazioni)
- Lucide React (icons)
- React Router

## Struttura Progetto

```
/src
├── types/          # TypeScript types
├── constants/      # Costanti e configurazioni
├── utils/          # Utility functions
└── components/     # Componenti React
    ├── layout/     # Layout components
    ├── features/   # Feature components
    ├── screens/    # Schermate principali
    └── ui/         # UI base components
```

## Accessibilità WCAG 2.1 AA

- Contrasto colori conforme (min 4.5:1)
- Target touch > 44px (Simple: 72px)
- Navigazione completa da tastiera
- ARIA labels su tutti gli elementi interattivi
- Screen reader optimized

## Personalizzazione

| Impostazione | Opzioni |
|--------------|---------|
| Font Size | 14px, 16px, 18px |
| Color Mode | Light, Dark, High Contrast |
| Complexity | Simple, Medium, Full |
| Language | Standard, Plain Language, Icons Only |
| Voice Speed | Lenta, Normale, Veloce |

## Installazione

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
npm run preview
```

## Documentazione

- `STRUCTURE.md` - Reference rapida struttura
- `CODE_GUIDELINES.md` - Standard di codifica
- `CHANGELOG.md` - Log modifiche
- `KEYBOARD_NAVIGATION.md` - Guida navigazione tastiera

## Palette Colori

- Primary: #003366 (Navy Blue)
- Secondary: #218281 (Teal)
- White: #FFFFFF
- Yellow: #FFFF00 (High Contrast)

## Tipografia

- Font Family: Open Sans
- Base Sizes: 14px, 16px, 18px

## Browser Support

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## Conformità

- WCAG 2.1 AA compliant
- GDPR ready
- Normativa sanitaria italiana

---

**Versione**: 2.0.0  
**Licenza**: Prototipo educativo