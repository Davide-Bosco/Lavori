# Struttura Progetto - Reference Veloce

## Cartelle Principali

```
/src
├── types/          # TypeScript types centralizzati
├── constants/      # Costanti (colori, personas, defaults)
├── utils/          # Utility functions (theme, keyboard, format)
└── components/     # Componenti React
```

## Import Pattern

```typescript
// Types
import { AppSettings, Persona } from '../types';

// Constants
import { BRAND_COLORS, PERSONAS } from '../constants';

// Utils
import { getColorScheme, getFontSize } from '../utils';

// Components
import { BottomNavigation } from '../components/layout';
```

## Utilities Essenziali

### Theme
- `getColorScheme(settings)` - Schema colori completo
- `getFontSize(base, variant)` - Font size scalato
- `getPrimaryButton(colorMode)` - Stili pulsante
- `getCardStyles(colorMode)` - Stili card

### Keyboard
- `handleKeyboardActivation(e, action)` - Enter/Space handler
- `getFocusableElements(container)` - Elementi focusabili

### Format
- `formatDate(date, language)` - Formatta date
- `formatTime(time, language)` - Formatta orari
- `simplifyText(text, maxWords)` - Plain language

## Checklist Pre-Commit

- [ ] No `console.log`
- [ ] No `any` types
- [ ] ARIA labels presenti
- [ ] Keyboard navigation testata
- [ ] Testato con 3 personas

## Documentazione

- `README.md` - Overview progetto
- `PROJECT_STRUCTURE.md` - Struttura dettagliata
- `CODE_GUIDELINES.md` - Standard codifica
- `CHANGELOG.md` - Log modifiche

---

**Quick Start**: Leggi README.md poi CODE_GUIDELINES.md
