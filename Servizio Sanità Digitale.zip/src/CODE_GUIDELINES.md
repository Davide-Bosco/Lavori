# Code Guidelines

Linee guida per codice di qualità e manutenibile.

## Principi Base

### DRY (Don't Repeat Yourself)
Evitare duplicazione. Usare utilities e componenti riusabili.

```typescript
// Evitare
const bgColor = settings.colorMode === 'Dark' ? '#1F2121' : 
                settings.colorMode === 'High Contrast' ? '#000000' : '#FFFFFF';

// Preferire
import { getColorScheme } from '../utils';
const colors = getColorScheme(settings);
```

### Single Responsibility
Ogni componente/funzione ha un singolo scopo.

### Type Safety
Sempre TypeScript. Evitare `any`.

```typescript
// Evitare
const data: any = fetchData();

// Preferire
interface UserData {
  name: string;
  age: number;
}
const data: UserData = fetchData();
```

## Template Componente

```typescript
import { motion } from 'motion/react';
import { AppSettings } from '../types';
import { getColorScheme, getFontSize } from '../utils';

interface ComponentProps {
  settings: AppSettings;
  onAction: () => void;
}

export function Component({ settings, onAction }: ComponentProps) {
  // 1. Hooks
  const [state, setState] = useState();
  
  // 2. Utilities
  const colors = getColorScheme(settings);
  
  // 3. Event handlers
  const handleClick = () => {
    onAction();
  };
  
  // 4. Early returns
  if (!settings) return null;
  
  // 5. Render
  return (
    <div style={{ backgroundColor: colors.background }}>
      {/* Content */}
    </div>
  );
}
```

## Styling

### Usa Utilities
```typescript
import { getColorScheme, getFontSize, getPrimaryButton } from '../utils';

const colors = getColorScheme(settings);
const buttonStyle = getPrimaryButton(settings.colorMode);
const fontSize = getFontSize(settings.fontSize, 'large');
```

### Evita Hardcoding
```typescript
// Evitare
border: '2px solid #000'

// Preferire
border: colors.cardBorder
```

## Accessibilità

### ARIA Labels (Obbligatorio)
```typescript
<button
  onClick={handleClick}
  aria-label="Chiudi notifica"
  tabIndex={0}
>
  <X size={20} />
</button>
```

### Keyboard Navigation
```typescript
import { handleKeyboardActivation } from '../utils/keyboard';

<button
  onClick={handleClick}
  onKeyDown={(e) => handleKeyboardActivation(e, handleClick)}
  tabIndex={0}
>
  Azione
</button>
```

### Focus Visibile
```typescript
className="focus:ring-2 focus:ring-blue-500 focus:outline-none"
```

### Checklist Accessibilità
- [ ] Tutti i pulsanti hanno `aria-label`
- [ ] Tutti gli elementi interattivi hanno `tabIndex={0}`
- [ ] Keyboard navigation funzionante (Enter/Space)
- [ ] Contrasto WCAG 2.1 AA (min 4.5:1)
- [ ] Target touch > 44px (Simple: 72px)
- [ ] Focus visibile su tutti gli elementi
- [ ] Screen reader tested

## Import Organization

```typescript
// 1. React e librerie esterne
import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Home, Settings } from 'lucide-react';

// 2. Types
import { AppSettings, Persona } from '../types';

// 3. Utils
import { getColorScheme, getFontSize } from '../utils';

// 4. Constants
import { BRAND_COLORS, PERSONAS } from '../constants';

// 5. Components
import { BottomNavigation } from '../components/layout';
```

## Performance

### Memoization
```typescript
// Calcoli costosi
const expensiveValue = useMemo(() => 
  computeExpensiveValue(data), 
  [data]
);

// Callbacks
const handleClick = useCallback(() => {
  doSomething();
}, [dependency]);
```

### Evita Re-renders
```typescript
// Evitare - crea nuovo oggetto ogni render
<Component style={{ color: 'red' }} />

// Preferire - oggetto stabile
const style = { color: 'red' };
<Component style={style} />
```

## Error Handling

```typescript
try {
  const data = await fetchData();
  setData(data);
} catch (error) {
  console.error('Failed to fetch:', error);
  setError('Impossibile caricare i dati');
}
```

## Commenti

### JSDoc per Funzioni Pubbliche
```typescript
/**
 * Calcola il contrasto tra due colori
 * @param color1 - Primo colore hex
 * @param color2 - Secondo colore hex
 * @returns Ratio di contrasto (1-21)
 */
function getContrastRatio(color1: string, color2: string): number {
  // Implementation
}
```

### Commenti Inline Solo Se Necessari
```typescript
// Buono - spiega logica complessa
// Calculate weighted average based on persona optimization
const weightedScore = scores.reduce((acc, score, idx) => 
  acc + (score * weights[idx]), 0
);

// Evitare - commento ovvio
// Increment counter
counter++;
```

## Pre-Commit Checklist

- [ ] No `console.log`
- [ ] No codice commentato
- [ ] No `any` types
- [ ] Tutti i componenti hanno interfaces
- [ ] No import inutilizzati
- [ ] ARIA labels presenti
- [ ] Keyboard navigation testata
- [ ] Testato con 3 personas

## Utilities Comuni

### Theme
```typescript
getColorScheme(settings)       // Schema colori completo
getFontSize(base, variant)     // Font size scalato
getPrimaryButton(colorMode)    // Stili pulsante primario
getCardStyles(colorMode)       // Stili card
```

### Keyboard
```typescript
handleKeyboardActivation(e, action)  // Enter/Space handler
getFocusableElements(container)      // Trova elementi focusabili
focusFirstElement(container)         // Focus primo elemento
trapFocus(e, container)              // Trap focus modali
```

### Format
```typescript
formatDate(date, language)     // Formatta date
formatTime(time, language)     // Formatta orari
simplifyText(text, maxWords)   // Plain language
truncateText(text, maxLength)  // Tronca con ellipsis
```

## Pattern Comuni

### Card Animata
```typescript
import { motion } from 'motion/react';
import { getCardStyles } from '../utils';

const cardStyle = getCardStyles(settings.colorMode);

<motion.div
  initial={{ opacity: 0, y: 20 }}
  animate={{ opacity: 1, y: 0 }}
  transition={{ delay: index * 0.1 }}
  className="rounded-lg p-4"
  style={cardStyle}
>
  {content}
</motion.div>
```

### Pulsante Primario
```typescript
import { motion } from 'motion/react';
import { getPrimaryButton } from '../utils';

const btnStyle = getPrimaryButton(settings.colorMode);

<motion.button
  whileTap={{ scale: 0.98 }}
  onClick={handleClick}
  style={btnStyle}
  aria-label="Azione"
  tabIndex={0}
>
  Conferma
</motion.button>
```

### Lista Navigabile
```typescript
import { useVerticalListNavigation } from '../hooks/useArrowNavigation';

const containerRef = useRef<HTMLDivElement>(null);
useVerticalListNavigation(containerRef);

<div ref={containerRef} className="space-y-3">
  {items.map(item => (
    <div key={item.id} tabIndex={0}>
      {item.content}
    </div>
  ))}
</div>
```

## Testing Personas

Testare ogni feature con:

1. **Maria** (72 anni, presbiopia)
   - Font size: 18px
   - Complexity: Simple
   - Language: Plain Language

2. **Giorgio** (68 anni, tremore)
   - Pulsanti grandi (72px)
   - Complexity: Medium
   - Spazi generosi

3. **Angela** (75 anni, MCI)
   - Color mode: High Contrast
   - Language: Icons Only
   - UI minimalista

---

**Note**: Seguire queste linee guida garantisce codice manutenibile e accessibile.
