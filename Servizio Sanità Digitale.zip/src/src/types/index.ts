/**
 * Core Application Types
 */

// Settings Types
export type FontSize = '14px' | '16px' | '18px';
export type ColorMode = 'Light' | 'Dark' | 'High Contrast';
export type Complexity = 'Simple' | 'Medium' | 'Full';
export type Language = 'Standard' | 'Plain Language' | 'Icons Only';
export type VoiceSpeed = 'Lenta' | 'Normale' | 'Veloce';

export interface AppSettings {
  fontSize: FontSize;
  colorMode: ColorMode;
  complexity: Complexity;
  language: Language;
  voiceSpeed: VoiceSpeed;
}

// Persona Types
export type PersonaType = 'Maria' | 'Giorgio' | 'Angela' | null;

export interface Persona {
  name: string;
  age: number;
  condition: string;
  needs: string[];
  optimizations: {
    fontSize: FontSize;
    colorMode: ColorMode;
    complexity: Complexity;
    language: Language;
    voiceSpeed: VoiceSpeed;
  };
  description: string;
  color: string;
  avatar: string;
}

// Screen Types
export type MainScreen = 'home' | 'ricette' | 'visite' | 'profilo' | 'sos';
export type SubScreen = 
  | 'settings' 
  | 'info-personali' 
  | 'misurazioni' 
  | 'promemoria' 
  | 'notifiche' 
  | 'documenti' 
  | 'privacy'
  | 'iot'
  | 'voice-recording'
  | 'visita-details'
  | 'nuova-visita';

export type Screen = MainScreen | SubScreen | 'onboarding' | 'section';

// Component Props
export interface BaseScreenProps {
  settings: AppSettings;
  persona: Persona | null;
}

export interface NavigableScreenProps extends BaseScreenProps {
  onNavigate: (screen: Screen) => void;
}

export interface BackableScreenProps extends BaseScreenProps {
  onBack: () => void;
}

// Data Models
export interface Ricetta {
  id: number;
  medication: string;
  dosage: string;
  frequency: string;
  doctor: string;
  validUntil: string;
  refills?: number;
  notes?: string;
}

export interface Visita {
  id: number;
  doctor: string;
  specialty: string;
  date: string;
  time: string;
  location: string;
  address?: string;
  phone?: string;
  notes?: string;
}

export interface Misurazione {
  id: number;
  type: 'Pressione' | 'Glicemia' | 'Peso' | 'Temperatura';
  value: string;
  date: string;
  time: string;
  icon: any;
  unit: string;
  status?: 'normal' | 'warning' | 'critical';
}

export interface Promemoria {
  id: number;
  title: string;
  time: string;
  frequency: string;
  icon: any;
  enabled: boolean;
  type: 'medication' | 'appointment' | 'measurement' | 'activity';
}

export interface Notifica {
  id: number;
  title: string;
  message: string;
  time: string;
  icon: any;
  read: boolean;
  type: 'info' | 'warning' | 'success' | 'appointment' | 'medication';
}

export interface Documento {
  id: number;
  title: string;
  type: string;
  date: string;
  icon: any;
  size?: string;
}

export interface PrivacySetting {
  id: string;
  icon: any;
  title: string;
  description: string;
  enabled: boolean;
  type: 'toggle' | 'action';
}

export interface IoTDevice {
  id: number;
  name: string;
  type: string;
  status: 'connected' | 'disconnected' | 'pairing';
  battery?: number;
  lastSync?: string;
  icon: any;
}

// Event Handlers
export type SettingsChangeHandler = (key: keyof AppSettings, value: any) => void;
export type PersonaChangeHandler = (persona: PersonaType) => void;
export type ScreenChangeHandler = (screen: Screen) => void;
