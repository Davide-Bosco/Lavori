/**
 * Color Constants - WCAG 2.1 AA Compliant
 */

export const BRAND_COLORS = {
  PRIMARY: '#003366',
  SECONDARY: '#218281',
  WHITE: '#FFFFFF',
  BLACK: '#000000',
  YELLOW: '#FFFF00',
} as const;

export const STATUS_COLORS = {
  SUCCESS: '#10b981',
  WARNING: '#f59e0b',
  ERROR: '#dc2626',
  INFO: '#3b82f6',
} as const;

export const THEME_CONFIG = {
  Light: {
    background: '#FFFFFF',
    text: '#000000',
    cardBg: '#E8E8E8',
    cardText: '#000000',
    cardBorder: '2px solid #000',
    inputBg: '#FFFFFF',
    inputText: '#000000',
    inputBorder: '2px solid #000',
    secondary: '#666666',
  },
  Dark: {
    background: '#1F2121',
    text: '#F5F5F5',
    cardBg: '#2a2a2a',
    cardText: '#F5F5F5',
    cardBorder: '2px solid #000',
    inputBg: '#1F2121',
    inputText: '#F5F5F5',
    inputBorder: '2px solid #666',
    secondary: '#D0D0D0',
  },
  'High Contrast': {
    background: '#000000',
    text: '#FFFF00',
    cardBg: '#FFFF00',
    cardText: '#000000',
    cardBorder: '3px solid #000000',
    inputBg: '#000000',
    inputText: '#FFFF00',
    inputBorder: '3px solid #FFFF00',
    secondary: '#FFFF00',
  },
} as const;

export type ColorMode = keyof typeof THEME_CONFIG;

export function getThemeColors(mode: ColorMode) {
  return THEME_CONFIG[mode];
}

export function getContrastColor(mode: ColorMode): string {
  return mode === 'High Contrast' ? BRAND_COLORS.YELLOW : BRAND_COLORS.BLACK;
}

export function getPrimaryButtonColors(mode: ColorMode) {
  return {
    background: mode === 'High Contrast' ? BRAND_COLORS.YELLOW : BRAND_COLORS.PRIMARY,
    color: mode === 'High Contrast' ? BRAND_COLORS.BLACK : BRAND_COLORS.WHITE,
    border: mode === 'High Contrast' ? '3px solid #000' : 'none',
  };
}

export function getSecondaryButtonColors(mode: ColorMode) {
  return {
    background: mode === 'High Contrast' ? BRAND_COLORS.BLACK : '#E8E8E8',
    color: mode === 'High Contrast' ? BRAND_COLORS.YELLOW : BRAND_COLORS.BLACK,
    border: mode === 'High Contrast' ? '3px solid #FFFF00' : '2px solid #000',
  };
}
