/**
 * Default Settings and Configuration
 */

import { AppSettings } from '../types';

export const DEFAULT_SETTINGS: AppSettings = {
  fontSize: '16px',
  colorMode: 'Light',
  complexity: 'Medium',
  language: 'Standard',
  voiceSpeed: 'Normale',
};

export const FONT_SIZE_OPTIONS = ['14px', '16px', '18px'] as const;
export const COLOR_MODE_OPTIONS = ['Light', 'Dark', 'High Contrast'] as const;
export const COMPLEXITY_OPTIONS = ['Simple', 'Medium', 'Full'] as const;
export const LANGUAGE_OPTIONS = ['Standard', 'Plain Language', 'Icons Only'] as const;
export const VOICE_SPEED_OPTIONS = ['Lenta', 'Normale', 'Veloce'] as const;

export const SECTION_NAMES = [
  'Architettura',
  'Personas',
  'Design System',
  'Wireframes',
  'Hotspots',
  'Mockup',
  'Login & Onboarding',
  'Interactive',
  'Accessibility Check',
  'Persona Optimization',
] as const;

export const MAIN_SCREENS = ['home', 'ricette', 'visite', 'profilo', 'sos'] as const;

export const HELP_TEXTS = {
  home: 'Panoramica delle tue informazioni di salute principali',
  ricette: 'Gestisci le tue prescrizioni mediche e farmaci',
  visite: 'Visualizza e prenota appuntamenti medici',
  profilo: 'Gestisci impostazioni e informazioni personali',
  sos: 'Accesso rapido ai contatti di emergenza',
  misurazioni: 'Monitora pressione, glicemia e altri parametri',
  promemoria: 'Imposta promemoria per farmaci e appuntamenti',
  notifiche: 'Visualizza gli avvisi importanti',
  documenti: 'Accedi ai tuoi documenti sanitari',
  privacy: 'Gestisci impostazioni di privacy e sicurezza',
  iot: 'Collega dispositivi medici intelligenti',
  settings: 'Personalizza l\'app secondo le tue esigenze',
} as const;
