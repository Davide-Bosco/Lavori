/**
 * Persona Definitions
 */

import { Persona } from '../types';

export const PERSONAS: Record<string, Persona> = {
  Maria: {
    name: 'Maria',
    age: 72,
    condition: 'Presbiopia',
    needs: ['Testo grande', 'Contrasto alto', 'Interfaccia semplice'],
    optimizations: {
      fontSize: '18px',
      colorMode: 'Light',
      complexity: 'Simple',
      language: 'Plain Language',
      voiceSpeed: 'Lenta',
    },
    description: 'Maria ha 72 anni e soffre di presbiopia. Ha bisogno di testi grandi e interfacce semplificate.',
    color: '#e91e63',
    avatar: '👵',
  },
  Giorgio: {
    name: 'Giorgio',
    age: 68,
    condition: 'Tremore alle mani',
    needs: ['Target grandi', 'Spazi ampi', 'Conferme chiare'],
    optimizations: {
      fontSize: '16px',
      colorMode: 'Light',
      complexity: 'Medium',
      language: 'Standard',
      voiceSpeed: 'Normale',
    },
    description: 'Giorgio ha 68 anni e presenta tremore alle mani. Necessita di pulsanti grandi e spazi ampi.',
    color: '#2196f3',
    avatar: '👴',
  },
  Angela: {
    name: 'Angela',
    age: 75,
    condition: 'Mild Cognitive Impairment',
    needs: ['Linguaggio semplice', 'Icone chiare', 'Promemoria costanti'],
    optimizations: {
      fontSize: '16px',
      colorMode: 'High Contrast',
      complexity: 'Simple',
      language: 'Icons Only',
      voiceSpeed: 'Lenta',
    },
    description: 'Angela ha 75 anni e soffre di MCI. Beneficia di linguaggio semplificato e rappresentazioni visive chiare.',
    color: '#9c27b0',
    avatar: '👵',
  },
};

export const DEFAULT_PERSONA = null;

export function getPersonaByName(name: string | null): Persona | null {
  if (!name) return null;
  return PERSONAS[name] || null;
}

export function getAllPersonas(): Persona[] {
  return Object.values(PERSONAS);
}

export function getPersonaOptimizations(personaName: string | null) {
  const persona = getPersonaByName(personaName);
  return persona?.optimizations || null;
}
