/**
 * Theme Utilities
 */

import { AppSettings, ColorMode, FontSize } from '../types';
import { getThemeColors, getPrimaryButtonColors, getSecondaryButtonColors } from '../constants/colors';

export function getColorScheme(settings: AppSettings) {
  return getThemeColors(settings.colorMode);
}

export function getBgColor(colorMode: ColorMode): string {
  const themes = getThemeColors(colorMode);
  return themes.background;
}

export function getTextColor(colorMode: ColorMode): string {
  const themes = getThemeColors(colorMode);
  return themes.text;
}

export function getCardStyles(colorMode: ColorMode) {
  const themes = getThemeColors(colorMode);
  return {
    backgroundColor: themes.cardBg,
    color: themes.cardText,
    border: themes.cardBorder,
  };
}

export function getInputStyles(colorMode: ColorMode) {
  const themes = getThemeColors(colorMode);
  return {
    backgroundColor: themes.inputBg,
    color: themes.inputText,
    border: themes.inputBorder,
  };
}

export function getPrimaryButton(colorMode: ColorMode) {
  return getPrimaryButtonColors(colorMode);
}

export function getSecondaryButton(colorMode: ColorMode) {
  return getSecondaryButtonColors(colorMode);
}

const FONT_SIZE_MAP = {
  '14px': { base: '14px', small: '12px', medium: '16px', large: '18px', xlarge: '20px' },
  '16px': { base: '16px', small: '14px', medium: '18px', large: '20px', xlarge: '22px' },
  '18px': { base: '18px', small: '16px', medium: '20px', large: '22px', xlarge: '24px' },
} as const;

export function getFontSize(
  baseFontSize: FontSize,
  variant: 'base' | 'small' | 'medium' | 'large' | 'xlarge' = 'base'
): string {
  return FONT_SIZE_MAP[baseFontSize][variant];
}

export function getIconSize(complexity: 'Simple' | 'Medium' | 'Full'): number {
  const sizes = { Simple: 32, Medium: 24, Full: 20 };
  return sizes[complexity];
}

export function getAvatarSize(complexity: 'Simple' | 'Medium' | 'Full'): string {
  const sizes = { Simple: '96px', Medium: '64px', Full: '48px' };
  return sizes[complexity];
}

export function getButtonHeight(complexity: 'Simple' | 'Medium' | 'Full'): string {
  const heights = { Simple: '72px', Medium: '64px', Full: '56px' };
  return heights[complexity];
}

export function getCardPadding(complexity: 'Simple' | 'Medium' | 'Full'): string {
  const paddings = { Simple: '24px', Medium: '20px', Full: '16px' };
  return paddings[complexity];
}

export function getCardShadow(colorMode: ColorMode): string {
  if (colorMode === 'High Contrast') return 'none';
  return '0 2px 4px rgba(0,0,0,0.1)';
}

export function getElevatedShadow(colorMode: ColorMode): string {
  if (colorMode === 'High Contrast') return 'none';
  return '0 4px 8px rgba(0,0,0,0.2)';
}

export function getAriaLabel(
  text: string,
  language: 'Standard' | 'Plain Language' | 'Icons Only'
): string {
  return text;
}

export function shouldShowText(language: 'Standard' | 'Plain Language' | 'Icons Only'): boolean {
  return language !== 'Icons Only';
}

export function simplifyText(text: string, language: 'Standard' | 'Plain Language' | 'Icons Only'): string {
  if (language === 'Plain Language') {
    return text.split(' ').slice(0, 3).join(' ');
  }
  return text;
}
