/**
 * Keyboard Navigation Utilities
 */

import { KeyboardEvent } from 'react';

export function handleKeyboardActivation(
  e: KeyboardEvent<HTMLElement>,
  action: () => void
): void {
  if (e.key === 'Enter' || e.key === ' ') {
    e.preventDefault();
    action();
  }
}

export function handleKeyboardNavigation(
  e: KeyboardEvent<HTMLElement>,
  direction: 'vertical' | 'horizontal' | 'both' = 'both'
): void {
  const { key } = e;
  
  if (direction === 'vertical' || direction === 'both') {
    if (key === 'ArrowUp' || key === 'ArrowDown') {
      e.preventDefault();
    }
  }
  
  if (direction === 'horizontal' || direction === 'both') {
    if (key === 'ArrowLeft' || key === 'ArrowRight') {
      e.preventDefault();
    }
  }
}

export function isActivationKey(key: string): boolean {
  return key === 'Enter' || key === ' ';
}

export function isNavigationKey(key: string): boolean {
  return ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(key);
}

export function getFocusableElements(container: HTMLElement): HTMLElement[] {
  const selector = [
    'a[href]',
    'button:not([disabled])',
    'input:not([disabled])',
    'select:not([disabled])',
    'textarea:not([disabled])',
    '[tabindex]:not([tabindex="-1"])',
  ].join(', ');
  
  return Array.from(container.querySelectorAll(selector));
}

export function focusFirstElement(container: HTMLElement): void {
  const elements = getFocusableElements(container);
  if (elements.length > 0) {
    elements[0].focus();
  }
}

export function focusLastElement(container: HTMLElement): void {
  const elements = getFocusableElements(container);
  if (elements.length > 0) {
    elements[elements.length - 1].focus();
  }
}

export function trapFocus(e: KeyboardEvent<HTMLElement>, container: HTMLElement): void {
  if (e.key !== 'Tab') return;

  const focusableElements = getFocusableElements(container);
  const firstElement = focusableElements[0];
  const lastElement = focusableElements[focusableElements.length - 1];

  if (e.shiftKey) {
    if (document.activeElement === firstElement) {
      e.preventDefault();
      lastElement.focus();
    }
  } else {
    if (document.activeElement === lastElement) {
      e.preventDefault();
      firstElement.focus();
    }
  }
}
