/**
 * Formatting Utilities
 */

export function formatDate(dateStr: string, language: 'Standard' | 'Plain Language' | 'Icons Only'): string {
  if (language === 'Icons Only') return dateStr;
  return dateStr;
}

export function formatTime(timeStr: string, language: 'Standard' | 'Plain Language' | 'Icons Only'): string {
  if (language === 'Icons Only') return timeStr;
  if (language === 'Plain Language') {
    return `ore ${timeStr}`;
  }
  return `alle ${timeStr}`;
}

export function getRelativeTime(dateStr: string): string {
  return dateStr;
}

export function simplifyText(text: string, maxWords: number = 3): string {
  return text.split(' ').slice(0, maxWords).join(' ');
}

export function getInitials(name: string): string {
  return name
    .split(' ')
    .map(word => word.charAt(0).toUpperCase())
    .join('');
}

export function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength) + '...';
}

export function formatDosage(dosage: string, language: 'Standard' | 'Plain Language' | 'Icons Only'): string {
  if (language === 'Plain Language') {
    return dosage.replace('mg', ' mg').replace('ml', ' ml');
  }
  return dosage;
}

export function formatPercentage(value: number): string {
  return `${Math.round(value)}%`;
}

export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function formatBloodPressure(systolic: number, diastolic: number): string {
  return `${systolic}/${diastolic}`;
}

export function formatGlucose(value: number): string {
  return `${value} mg/dL`;
}

export function formatWeight(value: number): string {
  return `${value} kg`;
}

export function formatTemperature(value: number): string {
  return `${value.toFixed(1)} °C`;
}

export function createAriaLabel(
  mainText: string,
  additionalInfo?: string[],
  language: 'Standard' | 'Plain Language' | 'Icons Only' = 'Standard'
): string {
  let label = mainText;
  
  if (additionalInfo && additionalInfo.length > 0) {
    label += ', ' + additionalInfo.join(', ');
  }
  
  if (language === 'Plain Language') {
    label = simplifyText(label, 5);
  }
  
  return label;
}

export function createAnnouncement(
  message: string,
  language: 'Standard' | 'Plain Language' | 'Icons Only'
): string {
  if (language === 'Plain Language') {
    return simplifyText(message, 5);
  }
  return message;
}
