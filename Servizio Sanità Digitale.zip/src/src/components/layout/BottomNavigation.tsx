import { Home, Pill, Stethoscope, User, Phone } from 'lucide-react';
import { useRef } from 'react';
import { useBottomNavArrowNavigation } from '../../hooks/useArrowNavigation';
import { MainScreen, ColorMode } from '../../types';
import { BRAND_COLORS } from '../../constants';

interface BottomNavigationProps {
  activeScreen: MainScreen;
  onNavigate: (screen: MainScreen) => void;
  colorMode: ColorMode;
}

export function BottomNavigation({ activeScreen, onNavigate, colorMode }: BottomNavigationProps) {
  const navRef = useRef<HTMLElement>(null);
  useBottomNavArrowNavigation(navRef);

  const navItems: Array<{ id: MainScreen; label: string; icon: typeof Home }> = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'ricette', label: 'Ricette', icon: Pill },
    { id: 'visite', label: 'Visite', icon: Stethoscope },
    { id: 'profilo', label: 'Profilo', icon: User },
    { id: 'sos', label: 'SOS', icon: Phone },
  ];

  const bgColor = colorMode === 'High Contrast' 
    ? BRAND_COLORS.BLACK 
    : colorMode === 'Dark' 
    ? '#1F2121' 
    : BRAND_COLORS.PRIMARY;
  
  const activeColor = colorMode === 'High Contrast' 
    ? BRAND_COLORS.YELLOW 
    : BRAND_COLORS.WHITE;
  
  const inactiveOpacity = colorMode === 'High Contrast' ? 0.5 : 0.7;

  return (
    <nav 
      ref={navRef}
      className="fixed bottom-0 left-0 right-0 flex justify-around items-center safe-bottom"
      style={{
        backgroundColor: bgColor,
        borderTop: colorMode === 'High Contrast' ? '3px solid #FFFF00' : '1px solid rgba(255,255,255,0.1)',
        height: '72px',
        zIndex: 100,
      }}
      role="navigation"
      aria-label="Navigazione principale"
    >
      {navItems.map((item) => {
        const Icon = item.icon;
        const isActive = activeScreen === item.id;
        
        return (
          <button
            key={item.id}
            onClick={() => onNavigate(item.id)}
            className="flex flex-col items-center justify-center gap-1 transition-opacity"
            style={{
              flex: 1,
              height: '100%',
              opacity: isActive ? 1 : inactiveOpacity,
              color: activeColor,
              backgroundColor: 'transparent',
              border: 'none',
              cursor: 'pointer',
            }}
            aria-label={item.label}
            aria-current={isActive ? 'page' : undefined}
            tabIndex={0}
          >
            <Icon size={24} aria-hidden="true" />
            <span style={{ fontSize: '11px', fontWeight: isActive ? '600' : '400' }}>
              {item.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
}
