import { ArrowLeft } from 'lucide-react';
import { motion } from 'motion/react';
import { AppSettings } from '../../types';
import { getColorScheme, getFontSize, getPrimaryButton, shouldShowText } from '../../utils';

interface ScreenHeaderProps {
  title: string;
  settings: AppSettings;
  onBack: () => void;
}

export function ScreenHeader({ title, settings, onBack }: ScreenHeaderProps) {
  const colors = getColorScheme(settings);
  const primaryBtn = getPrimaryButton(settings.colorMode);

  return (
    <div 
      className="flex items-center gap-3 p-4"
      style={{
        backgroundColor: colors.cardBg,
        borderBottom: `2px solid ${settings.colorMode === 'High Contrast' ? '#000' : '#000'}`,
      }}
    >
      <motion.button
        whileTap={{ scale: 0.95 }}
        onClick={onBack}
        className="rounded-lg p-2"
        style={{
          backgroundColor: primaryBtn.background,
        }}
        aria-label={settings.language === 'Plain Language' ? 'Indietro' : 'Torna Indietro'}
        tabIndex={0}
      >
        <ArrowLeft size={24} color={primaryBtn.color} />
      </motion.button>
      {shouldShowText(settings.language) && (
        <h1 style={{
          fontSize: getFontSize(settings.fontSize, 'large'),
          fontWeight: '600',
          color: colors.cardText,
        }}>
          {title}
        </h1>
      )}
    </div>
  );
}
