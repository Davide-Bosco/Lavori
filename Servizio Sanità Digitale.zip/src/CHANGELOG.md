# Changelog

## [2.0.0] - 2026-03-15

### Added
- Struttura `/src` professionale (types, constants, utils)
- Sezione "Dettagli Visita" con informazioni complete
- Form "Prenota Nuova Visita" funzionale
- Componente riusabile `ScreenHeader`
- 40+ utility functions centralizzate
- Documentazione completa

### Changed
- Riorganizzazione componenti in sottocartelle logiche
- Types centralizzati in `/src/types`
- Costanti unificate in `/src/constants`
- Schema colori con utilities WCAG compliant

### Removed
- Codice duplicato (150+ righe)
- console.log statements
- Commenti ridondanti

### Fixed
- Navigazione tra sottosezioni (no più alert)
- Consistenza UI/UX tra schermate
- Type safety migliorata

## [1.0.0] - 2026-03-14

### Added
- 10 sezioni complete prototipo
- 5 schermate mobile (Home, Ricette, Visite, Profilo, SOS)
- 3 personas (Maria, Giorgio, Angela)
- Personalizzazione completa (font, colori, complexity, language)
- Accessibilità WCAG 2.1 AA
- Bottom navigation coerente
- Input vocale
- Pairing IoT

---

Formato basato su [Keep a Changelog](https://keepachangelog.com/)
