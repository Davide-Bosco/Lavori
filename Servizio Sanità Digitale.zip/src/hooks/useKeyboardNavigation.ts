import { useEffect, useRef, RefObject } from 'react';

export interface KeyboardNavigationOptions {
  enabled?: boolean;
  onEscape?: () => void;
  onEnter?: () => void;
  trapFocus?: boolean;
  autoFocus?: boolean;
}

/**
 * Hook for managing keyboard navigation within a component
 * Provides focus management and keyboard shortcuts
 */
export function useKeyboardNavigation(
  containerRef: RefObject<HTMLElement>,
  options: KeyboardNavigationOptions = {}
) {
  const { 
    enabled = true, 
    onEscape, 
    onEnter, 
    trapFocus = false,
    autoFocus = false 
  } = options;

  const firstFocusableRef = useRef<HTMLElement | null>(null);
  const lastFocusableRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if (!enabled || !containerRef.current) return;

    const container = containerRef.current;

    // Get all focusable elements
    const getFocusableElements = (): HTMLElement[] => {
      const selector = [
        'a[href]',
        'button:not([disabled])',
        'input:not([disabled])',
        'select:not([disabled])',
        'textarea:not([disabled])',
        '[tabindex]:not([tabindex="-1"])',
      ].join(',');

      return Array.from(container.querySelectorAll(selector)) as HTMLElement[];
    };

    // Auto-focus first element if requested
    if (autoFocus) {
      const focusables = getFocusableElements();
      if (focusables.length > 0) {
        focusables[0].focus();
      }
    }

    // Handle keyboard events
    const handleKeyDown = (e: KeyboardEvent) => {
      // ESC key
      if (e.key === 'Escape' && onEscape) {
        e.preventDefault();
        onEscape();
        return;
      }

      // ENTER key (when on a non-button element)
      if (e.key === 'Enter' && onEnter && e.target !== document.body) {
        const target = e.target as HTMLElement;
        if (target.tagName !== 'BUTTON' && target.tagName !== 'A') {
          e.preventDefault();
          onEnter();
          return;
        }
      }

      // Focus trap (TAB key)
      if (trapFocus && e.key === 'Tab') {
        const focusables = getFocusableElements();
        if (focusables.length === 0) return;

        firstFocusableRef.current = focusables[0];
        lastFocusableRef.current = focusables[focusables.length - 1];

        // Shift + Tab (backward)
        if (e.shiftKey) {
          if (document.activeElement === firstFocusableRef.current) {
            e.preventDefault();
            lastFocusableRef.current?.focus();
          }
        } 
        // Tab (forward)
        else {
          if (document.activeElement === lastFocusableRef.current) {
            e.preventDefault();
            firstFocusableRef.current?.focus();
          }
        }
      }
    };

    container.addEventListener('keydown', handleKeyDown);

    return () => {
      container.removeEventListener('keydown', handleKeyDown);
    };
  }, [enabled, onEscape, onEnter, trapFocus, autoFocus, containerRef]);

  return {
    firstFocusableRef,
    lastFocusableRef,
  };
}

/**
 * Hook for managing global keyboard shortcuts
 */
export function useKeyboardShortcuts(shortcuts: Record<string, () => void>, enabled = true) {
  useEffect(() => {
    if (!enabled) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      // Create a key combination string (e.g., "Control+S", "Alt+H")
      const key = [
        e.ctrlKey && 'Control',
        e.altKey && 'Alt',
        e.shiftKey && 'Shift',
        e.key,
      ]
        .filter(Boolean)
        .join('+');

      const handler = shortcuts[key];
      if (handler) {
        e.preventDefault();
        handler();
      }
    };

    window.addEventListener('keydown', handleKeyDown);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [shortcuts, enabled]);
}
