# 🎯 Navigazione da Tastiera - Guida Completa

## Panoramica

L'applicazione di sanità digitale supporta **navigazione completa da tastiera** conforme a WCAG 2.1 AA, con supporto per:
- ⌨️ **Tab/Shift+Tab** - Navigazione sequenziale
- ⬆️⬇️⬅️➡️ **Arrow Keys** - Navigazione direzionale
- ⏎ **Enter/Space** - Attivazione elementi
- ⎋ **Escape** - Chiusura modali
- **Alt+Shortcuts** - Scorciatoie rapide

## 🔑 Scorciatoie da Tastiera

### Scorciatoie Globali (Alt+Key)

| Tasto | Funzione | Descrizione |
|-------|----------|-------------|
| **Alt+1** | Home | Vai alla schermata Home |
| **Alt+2** | Ricette | Vai alla schermata Ricette |
| **Alt+3** | Visite | Vai alla schermata Visite |
| **Alt+4** | Profilo | Vai alla schermata Profilo |
| **Alt+5** | SOS | Vai alla schermata SOS |
| **Alt+S** | Settings | Apri pannello Impostazioni |
| **Alt+H** | Help | Mostra guida scorciatoie |

### Scorciatoie di Navigazione

| Tasto | Funzione | Descrizione |
|-------|----------|-------------|
| **Tab** | Avanti | Naviga all'elemento successivo |
| **Shift+Tab** | Indietro | Naviga all'elemento precedente |
| **Enter/Space** | Attiva | Attiva l'elemento selezionato |
| **Esc** | Chiudi | Chiude modali o torna indietro |

### Scorciatoie di Navigazione Direzionale

| Tasto | Funzione | Descrizione |
|-------|----------|-------------|
| **Freccia Su** | Su | Naviga verso l'elemento superiore |
| **Freccia Giù** | Giù | Naviga verso l'elemento inferiore |
| **Freccia Sinistra** | Sinistra | Naviga verso l'elemento a sinistra |
| **Freccia Destra** | Destra | Naviga verso l'elemento a destra |

## 🛠️ Componenti Implementati

### 1. **useArrowNavigation Hook** (`/hooks/useArrowNavigation.ts`)
Hook personalizzato per gestire navigazione con arrow keys:
- **Navigazione Verticale**: ArrowUp/ArrowDown per liste verticali
- **Navigazione Orizzontale**: ArrowLeft/ArrowRight per menu orizzontali
- **Navigazione Grid**: supporto per griglie 2D
- **Loop Navigation**: ritorna al primo quando raggiungi l'ultimo
- **Auto-scroll**: scroll automatico dell'elemento in focus
- **Selezione intelligente**: filtra elementi invisibili o disabilitati

#### Hooks Specializzati:
- **useBottomNavArrowNavigation**: Per la bottom navigation (ArrowLeft/ArrowRight)
- **useVerticalListNavigation**: Per liste verticali (ArrowUp/ArrowDown)
- **useGridNavigation**: Per griglie con numero di colonne configurabile

### 2. **useKeyboardNavigation Hook** (`/hooks/useKeyboardNavigation.ts`)
Hook personalizzato per gestire la navigazione da tastiera all'interno di componenti:
- Focus trap per modali
- Auto-focus su primo elemento
- Gestione ESC e ENTER keys
- Tracciamento primo e ultimo elemento focusabile

### 3. **useKeyboardShortcuts Hook** (`/hooks/useKeyboardNavigation.ts`)
Hook per gestire scorciatoie globali da tastiera:
- Supporto per combinazioni di tasti (Ctrl, Alt, Shift)
- Prevenzione comportamenti default quando necessario
- Enable/disable dinamico

### 4. **KeyboardNavigationWrapper** (`/components/KeyboardNavigationWrapper.tsx`)
Componente wrapper che fornisce navigazione da tastiera all'intera app:
- Definisce tutte le scorciatoie globali
- Gestisce navigazione tra schermate
- Implementa focus trap condizionale per modali

### 5. **SkipLinks** (`/components/SkipLinks.tsx`)
Componente per skip links e guida scorciatoie:
- Skip links visibili solo al focus
- Modal con elenco completo scorciatoie (Alt+H)
- Stili adattivi per ogni modalità colore
- Design accessibile e chiaro

## 📱 Schermate con Supporto Keyboard

### Schermate Principali
- ✅ **HomeScreen**: Navigazione card, bottoni settings
- ✅ **RicetteScreen**: Navigazione lista ricette
- ✅ **VisiteScreen**: Navigazione appuntamenti
- ✅ **ProfiloScreen**: Navigazione dati personali
- ✅ **SOSScreen**: Navigazione contatti emergenza

### Schermate Modali (con ESC support)
- ✅ **SettingsScreen**: ESC per tornare indietro
- ✅ **VoiceRecordingScreen**: ESC per annullare registrazione
- ✅ **IoTScreen**: ESC per annullare pairing

### Componenti Interattivi
- ✅ **BottomNavigation**: Supporto accessKey (Alt+1 a Alt+5)
- ✅ **CardItem**: Supporto Enter e Spazio
- ✅ **VoiceIoTButtons**: Supporto Enter e Spazio
- ✅ **SettingsScreen buttons**: Navigazione opzioni con tastiera

## 🎨 Stili di Focus per Modalità Colore

### Normal Mode
```css
outline: 3px solid #218281;
outline-offset: 2px;
```

### High Contrast Mode
```css
outline: 3px solid #FFFF00;
outline-offset: 2px;
```

### Dark Mode
```css
outline: 3px solid #218281;
outline-offset: 2px;
```

## 🧪 Test di Accessibilità

### Checklist WCAG 2.1 AA
- ✅ **2.1.1 Keyboard**: Tutte le funzioni utilizzabili da tastiera
- ✅ **2.1.2 No Keyboard Trap**: Nessun elemento blocca il focus
- ✅ **2.4.1 Bypass Blocks**: Skip links implementati
- ✅ **2.4.3 Focus Order**: Ordine di focus logico
- ✅ **2.4.7 Focus Visible**: Indicatore di focus sempre visibile
- ✅ **4.1.2 Name, Role, Value**: ARIA labels appropriati

### Test Manuali Raccomandati
1. ☑️ Navigare l'intera app usando solo Tab/Shift+Tab
2. ☑️ Testare tutti gli shortcuts (Alt+1-5, Alt+S, Alt+H)
3. ☑️ Verificare skip links premendo Tab all'apertura
4. ☑️ Testare focus trap in schermate modali (Settings, Voice, IoT)
5. ☑️ Verificare ESC per chiudere modali
6. ☑️ Testare con screen reader (NVDA, JAWS, VoiceOver)
7. ☑️ Testare in tutte e 3 le modalità colore

## 📖 Utilizzo per Utenti

### Navigazione Base
1. Premi `Tab` per muoverti tra gli elementi
2. Premi `Enter` o `Spazio` per attivare bottoni
3. Usa le frecce per navigare in liste e menu

### Navigazione con Arrow Keys
**Bottom Navigation (menu inferiore):**
- `←` Freccia Sinistra: vai al tab precedente
- `→` Freccia Destra: vai al tab successivo
- Loop automatico: dalla fine torna all'inizio

**Liste Verticali (Ricette, Visite, SOS):**
- `↑` Freccia Su: vai all'elemento precedente
- `↓` Freccia Giù: vai all'elemento successivo
- Loop automatico: dall'ultimo torna al primo
- Scroll automatico dell'elemento in focus

**Impostazioni:**
- `↑`/`↓`: naviga tra le opzioni
- `Tab`: passa al prossimo campo

### Scorciatoie Rapide
- `Alt + H`: Apri la guida alle scorciatoie
- `Alt + 1`: Vai a Home
- `Alt + 2`: Vai a Ricette  
- `Alt + 3`: Vai a Visite
- `Alt + 4`: Vai a Profilo
- `Alt + 5`: Vai a SOS
- `Alt + S`: Apri Impostazioni

### Skip Links
1. Premi `Tab` quando apri la pagina
2. Vedrai apparire "Salta al contenuto principale"
3. Premi `Enter` per saltare direttamente al contenuto

## 🔧 Configurazione Tecnica

### Installazione
Non è necessaria alcuna installazione aggiuntiva. Il sistema di keyboard navigation è integrato nel codice base.

### Personalizzazione
Per modificare le scorciatoie da tastiera, modifica il file:
```typescript
/components/KeyboardNavigationWrapper.tsx
```

Nel oggetto `shortcuts`:
```typescript
const shortcuts = {
  'Alt+1': () => onNavigate('home'),
  'Alt+s': () => onSettingsOpen(),
  // Aggiungi qui nuove scorciatoie
};
```

## 🌐 Compatibilità Browser

| Browser | Versione Minima | Supporto |
|---------|----------------|----------|
| Chrome  | 90+            | ✅ Completo |
| Firefox | 88+            | ✅ Completo |
| Safari  | 14+            | ✅ Completo |
| Edge    | 90+            | ✅ Completo |

## 📚 Risorse Aggiuntive

- [WCAG 2.1 Guidelines](https://www.w3.org/WAI/WCAG21/quickref/)
- [Keyboard Accessibility](https://webaim.org/techniques/keyboard/)
- [ARIA Authoring Practices](https://www.w3.org/WAI/ARIA/apg/)

## 🎯 Prossimi Miglioramenti

- [✅] Supporto per navigazione con arrow keys nelle liste
- [ ] Annunci vocali per screen reader quando cambia schermata
- [ ] Modalità "keyboard only" con indicatori visivi aggiuntivi
- [ ] Tour guidato interattivo delle scorciatoie al primo avvio

---

**✓ WCAG 2.1 Level AA Compliant**  
**Versione**: 2.0.0  
**Ultimo aggiornamento**: Gennaio 2025